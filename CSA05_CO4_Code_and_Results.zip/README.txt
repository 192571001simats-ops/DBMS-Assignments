CSA05 DATABASE MANAGEMENT SYSTEMS ASSIGNMENT 4 CO4
Athisaya U | 192571001

Run: python3 CSA05_CO4_Experiment.py
Python 3 standard library only. The full run uses datasets through one million
records and 200000 random gateway insertions, so allow several minutes.
Output CSVs are overwritten in the script folder. Timing varies by machine.

The simulator models pages, not physical disk latency or crash recovery.
Baseline: heap, full-row static hash, clustered B+ tree with lazy deletion.
The compact gateway index has 255 entries/page; full records have20/page.
The hybrid comparison appends complete20-record batches. Dynamic hashing
and eager B+ deletion are explained analytically in the report.

results.csv: measured per-operation means, including oracle check time.
structure.csv: allocated pages, height, fill, overflow and construction I/O.
upi.csv: full200000-insert comparison on one million existing random keys.
validation.json: boundary, duplicate, split, overflow and locator checks.
btree_trace.json / bplus_trace.json: small order4 teaching traces.
tree_trace.py: reproduces B-tree insertion and eager deletion traces.
performance.png: plot used in the report.

The final code corrects the compact index payload to point to the original
ingestion sequence for initial rows. This payload-only correction preserves
all measured page accesses; it was additionally checked for1000 keys.
