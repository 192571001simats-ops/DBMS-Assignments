import json
class N:
 def __init__(self,leaf=True):self.k=[];self.c=[];self.leaf=leaf
class BT:
 def __init__(self):self.root=N();self.events=[]
 def split(self,p,i):
  a=p.c[i];b=N(a.leaf);mid=a.k[1];b.k=a.k[2:];a.k=a.k[:1]
  if not a.leaf:b.c=a.c[2:];a.c=a.c[:2]
  p.k.insert(i,mid);p.c.insert(i+1,b);self.events.append('split promotes '+str(mid))
 def insert(self,k):
  if len(self.root.k)==3:
   p=N(False);p.c=[self.root];self.root=p;self.split(p,0)
  def go(p):
   if p.leaf:p.k.append(k);p.k.sort();return
   i=0
   while i<len(p.k) and k>p.k[i]:i+=1
   if len(p.c[i].k)==3:
    self.split(p,i)
    if k>p.k[i]:i+=1
   go(p.c[i])
  go(self.root)
 def delete(self,k):
  def merge(p,i):
   a,b=p.c[i:i+2];a.k+=[p.k.pop(i)]+b.k;a.c+=b.c;p.c.pop(i+1);self.events.append('merge around separator')
  def go(p,k):
   i=0
   while i<len(p.k) and k>p.k[i]:i+=1
   if i<len(p.k) and k==p.k[i]:
    if p.leaf:p.k.pop(i);return
    if len(p.c[i].k)>=2:
     q=p.c[i]
     while not q.leaf:q=q.c[-1]
     old=q.k[-1];p.k[i]=old;go(p.c[i],old)
    elif len(p.c[i+1].k)>=2:
     q=p.c[i+1]
     while not q.leaf:q=q.c[0]
     old=q.k[0];p.k[i]=old;go(p.c[i+1],old)
    else:merge(p,i);go(p.c[i],k)
   elif not p.leaf:
    if len(p.c[i].k)==1:
     if i and len(p.c[i-1].k)>=2:
      a,b=p.c[i-1],p.c[i];b.k.insert(0,p.k[i-1]);p.k[i-1]=a.k.pop()
      if not a.leaf:b.c.insert(0,a.c.pop())
      self.events.append('redistribute from left')
     elif i+1<len(p.c) and len(p.c[i+1].k)>=2:
      a,b=p.c[i],p.c[i+1];a.k.append(p.k[i]);p.k[i]=b.k.pop(0)
      if not b.leaf:a.c.append(b.c.pop(0))
      self.events.append('redistribute from right')
     elif i+1<len(p.c):merge(p,i)
     else:merge(p,i-1);i-=1
    go(p.c[i],k)
  go(self.root,k)
  if not self.root.leaf and not self.root.k:self.root=self.root.c[0];self.events.append('root contracts')
 def state(self):
  out=[];q=[self.root]
  while q:out.append(' | '.join(str(p.k) for p in q));q=[c for p in q for c in p.c]
  return ' / '.join(out)
b=BT();tr=[]
for k in range(1,16):
 b.events=[];b.insert(k);tr.append([str(k),'; '.join(b.events) or 'no split',b.state()])
deltr=[]
for k in [1,2,3,4]:
 b.events=[];b.delete(k);deltr.append([str(k),'; '.join(b.events) or 'remove from leaf',b.state()])
json.dump({'insert':tr,'delete':deltr},open('work/btree_trace.json','w'),indent=2)
print(deltr)
